def reference(x):
	return math.sqrt(x)